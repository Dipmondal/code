(function() {

    var navToggler = document.querySelector('.nav-toggle');
    var navMenu = document.querySelector('.nav-menu');
    var isNavHidden = true;
    

    function toggleNavMenu() {
        if(!isNavHidden) {
            navMenu.style.display = 'none';
        } else {
            navMenu.style.display = 'flex';
        }
        isNavHidden = !isNavHidden;
    }
    navToggler.addEventListener('click', function(e) {
        e.preventDefault();
        toggleNavMenu();
    });

})();